#!/bin/bash
# Screenshot runs (not a measurement): pi_mpi.py with 32 processes on 8 workers, 4 times
export LC_ALL=C.UTF-8
MPI_OPTS="--mca btl_tcp_if_include eth0 --prtemca oob_tcp_if_include eth0 -x OPENBLAS_NUM_THREADS=1 -x OPENBLAS_CORETYPE=ARMV8 -x OMP_NUM_THREADS=1 -x LC_ALL"
H="worker1:4,worker2:4,worker3:4,worker4:4,worker5:4,worker6:4,worker7:4,worker8:4"
for k in 1 2 3 4; do
    echo "$(date '+%H:%M:%S') start run $k"
    mpirun --host "$H" -np 32 $MPI_OPTS python3 /opt/mpi/pi_mpi.py 9600000000
    echo "$(date '+%H:%M:%S') end run $k"
done
